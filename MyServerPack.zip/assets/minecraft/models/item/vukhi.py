import os
import json

# Danh sách 45 viên ngọc mới (đã xóa 'endersurge' và 'inferno' vì đã có sẵn)
new_gems = [
    "aether", "arachnarch", "archmage", "armor", "ars_mana", "bee_queen", "bloodcaster", "blue_skies", "cataclysm",
    "corrupted", "darkheart", "decay", "despicable", "draconic_legacy", "dracula", "enchanter", "engineer", "felfire",
    "flesh", "forlorn", "hearty", "hive", "horizonite_alchemist", "marrow", "master_crafter", "midnight",
    "mystic", "purity", "rat_chef", "reinforced", "safari", "sculk", "soultwisted", "thermal", "twin_magi", "twisted", "umbral_matrimony", "undergarden",
    "uranium", "ventium_alchemist", "vitalic", "wildheart", "witch_queen", "witherstorm", "zanite_alchemist"
]

output_dir = r"D:\sv\MyServerPack\models_output"
os.makedirs(output_dir, exist_ok=True)

print(f"Đang tiến hành khai sinh cho {len(new_gems)} viên ngọc mới...\n")

for index, gem in enumerate(new_gems, start=29): # Bắt đầu đếm từ 29
    model_data = {
        "parent": "item/generated",
        "textures": {
            "layer0": f"item/{gem}"
        }
    }
    
    file_path = os.path.join(output_dir, f"{gem}.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(model_data, f, indent=2)

print(f"✅ Đã tạo xong {len(new_gems)} file con. Nhớ copy chúng vào thư mục models/item của server nha!")