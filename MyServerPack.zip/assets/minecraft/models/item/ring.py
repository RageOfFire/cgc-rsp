import os
import json

# Danh sách 25 chiếc nhẫn (đã lọc bỏ file .mcmeta)
rings = [
    "ring_dolphin", "ring_experience", "ring_fire_resistance", "ring_flight", "ring_growth",
    "ring_health", "ring_hungerless", "ring_invisibility", "ring_jump_boost", "ring_knockback_resistance",
    "ring_luck", "ring_magnetism", "ring_mining", "ring_night_vision", "ring_poison_resistance",
    "ring_regeneration", "ring_slow_falling", "ring_slow_resistance", "ring_speed", "ring_sponge",
    "ring_strength", "ring_undying", "ring_water_breathing", "ring_water_walking", "ring_wither"
]

# Vẫn xuất ra ổ D quen thuộc
output_dir = r"D:\sv\MyServerPack\models_output"
os.makedirs(output_dir, exist_ok=True)

print(f"Đang tiến hành khai sinh cho {len(rings)} chiếc nhẫn...\n")

for index, ring in enumerate(rings, start=1): # Bắt đầu từ ID 1 cho vật chủ mới
    model_data = {
        "parent": "item/generated",
        "textures": {
            "layer0": f"item/{ring}"
        }
    }
    
    file_path = os.path.join(output_dir, f"{ring}.json")
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(model_data, f, indent=2)

print(f"✅ Đã tạo xong {len(rings)} file con. Nhớ ném chúng vào thư mục models/item nhé!\n")
print("👇 Copy cục dưới đây dán vào phần 'overrides' của file vật chủ mới (Ví dụ: gold_nugget.json) 👇\n")

formatted_overrides = ",\n".join(
    f'    {{ "predicate": {{ "custom_model_data": {i+1} }}, "model": "item/{r}" }}' 
    for i, r in enumerate(rings)
)

print('"overrides": [')
print(formatted_overrides)
print(']')