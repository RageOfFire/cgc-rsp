# Danh sách 40 món vũ khí lúc nãy
weapons = [
    "diamond_claymore", "diamond_cutlass", "diamond_glaive", "diamond_greataxe", "diamond_halberd",
    "diamond_katana", "diamond_longsword", "diamond_rapier", "diamond_sai", "diamond_scythe",
    "diamond_spear", "diamond_twinblade", "diamond_warglaive",
    "iron_claymore", "iron_cutlass", "iron_glaive", "iron_greataxe", "iron_halberd",
    "iron_katana", "iron_longsword", "iron_rapier", "iron_sai", "iron_scythe",
    "iron_spear", "iron_twinblade", "iron_warglaive",
    "netherite_claymore", "netherite_cutlass", "netherite_glaive", "netherite_greataxe", "netherite_halberd",
    "netherite_katana", "netherite_longsword", "netherite_rapier", "netherite_sai", "netherite_scythe",
    "netherite_spear", "netherite_twinblade", "netherite_warglaive",
    "lichblade"
]

yaml_output = ""

# Đếm từ ID 5 (vì 1-4 là đồ Hololive rồi)
for index, weapon in enumerate(weapons, start=5):
    # Đổi tên file thành tên hiển thị (VD: diamond_claymore -> Diamond Claymore)
    display_name = weapon.replace("_", " ").title()
    
    # Ép ID viết hoa toàn bộ cho chuẩn MMOItems (VD: DIAMOND_CLAYMORE)
    item_id = weapon.upper()
    
    # Tạo cấu trúc YAML cơ bản
    yaml_block = f"""{item_id}:
  base:
    material: IRON_SWORD
    name: '&f{display_name}'
    attack-damage: 10
    custom-model-data: {index}
"""
    yaml_output += yaml_block

# Lưu ra file text cho dễ copy
with open("mmoitems_swords.txt", "w", encoding="utf-8") as f:
    f.write(yaml_output)

print("✅ Đã đẻ xong cấu hình MMOItems! Mở file mmoitems_swords.txt ra mà húp nhé!")